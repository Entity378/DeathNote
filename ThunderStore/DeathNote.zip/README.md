# Death Note

## Description
Adds the Death Note as a rare scrap item to kill your friends with! 

## Features/How to use

- While holding the book, type this command in chat "/deathnote {playerUsername}"
- Use left click to activate the book and kill the targeted player with a heart attack

## Upcoming Plans

- Ability to learn monster names somehow and kill them with the book
- A usable UI instead of a command with a book open
- Animation when opening the book
- My favorite: Ability to specify a type of death after the players name, depending on the type, it will spawn any enemy that kills using that type to kill your target. The monster will have increased speed, health and damage. If it doesnt kill them in a certain amount of time, they will die from a heart attack.
- Special conditions like needing to see the player in the factory (or any location) before you can use their name, time to specify cause of death, etc
- Custom configs

## Support
You can support me at my kofi page. Any money will go towards making more mods and hiring people to make models since I have absolutely no artistic talent (lol)

https://ko-fi.com/snowlance

## Attribution
Model by pedrohmm123 at https://sketchfab.com/3d-models/death-note-anime-book-fanart-970248251f124cddbfc2b4999c43b713